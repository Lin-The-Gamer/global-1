// ignore_for_file: prefer_const_constructors_in_immutables, prefer_const_constructors

import 'package:film_app/detailScreen.dart';
import 'package:film_app/film.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData.dark(),
      home: ListaPage(),
    );
  }
}

class ListaPage extends StatefulWidget {
  ListaPage({super.key});

  @override
  State<ListaPage> createState() => _ListaPageState();
}

class _ListaPageState extends State<ListaPage> {
  final List<Films> film = [
    Films(
        'images/filme1.png',
        'Ação, Super-Herói, Marvel, Tecnologia',
        'Homem de Ferro',
        'Jon Favreau',
        '2008',
        'O filme foi lançado é o primeiro capítulo do Universo Cinematográfico Marvel (MCU), dirigido por Jon Favreau e estrelado por Robert Downey Jr. como Tony Stark, um gênio bilionário que constrói uma poderosa armadura para se tornar o super-herói Homem de Ferro.',
        '7,9/10',
        false),
    Films(
        'images/filme2.png',
        'Ação, Super-Herói, Mitologia, Marvel',
        'Thor',
        'Kenneth Branagh',
        '2011',
        'É um filme baseado no personagem da Marvel Comics, dirigido por Kenneth Branagh. Ele apresenta Chris Hemsworth como Thor, o poderoso deus do trovão, que é banido de Asgard para a Terra e deve aprender a ser um verdadeiro herói enquanto enfrenta ameaças tanto em seu mundo natal quanto no novo.',
        '7/10',
        false),
    Films(
        'images/filme3.png',
        'Ação, Super-Herói, Guerra, Marvel',
        'Capitão América: O Primeiro Vingador ',
        'Joe Johnston',
        '2011',
        'É um filme dirigido por Joe Johnston. Ele segue a história de Steve Rogers, interpretado por Chris Evans, um jovem franzino que se voluntaria para um experimento militar que o transforma no super soldado conhecido como Capitão América.',
        '6,9/10',
        false),
    Films(
        'images/filme4.png',
        'Animação, Aventura, Corrida, Espionagem',
        'Carros 2',
        'John Lasseter e Brad Lewis',
        '2011',
        'É um filme de animação lançado pela Pixar Animation Studios. O filme acompanha Relâmpago McQueen e seu amigo Mate em uma viagem ao redor do mundo para competir no Grand Prix Mundial.',
        '6,2/10',
        false),
    Films(
        'images/filme5.png',
        'Ação, Super-Herói, Adolescente, Marvel',
        'Homem-Aranha: De Volta ao Lar',
        'Jon Watts',
        '2017',
        'Este filme marca a estreia do Homem-Aranha no Universo Cinematográfico Marvel (MCU). No filme, Tom Holland interpreta Peter Parker, um jovem estudante do ensino médio que tenta equilibrar sua vida como adolescente com suas responsabilidades como o herói Homem-Aranha.',
        '7,4/10',
        false),
    Films(
        'images/filme6.png',
        'Animação, Aventura, Amizade, Família',
        'Toy Story 4',
        'Josh Cooley',
        '2019',
        'Woody, Buzz Lightyear e o resto dos brinquedos embarcam em uma nova aventura quando a jovem Bonnie cria um novo brinquedo chamado Forky. Durante uma viagem, Woody encontra sua antiga amiga Bo Peep e descobre um novo propósito para sua vida.',
        '7,7/10',
        false),
    Films(
        'images/filme7.png',
        'Aventura, Arqueologia, Tesouro, Mistério',
        'Indiana Jones e a Relíquia do Destino',
        'Steven Spielberg',
        '2023',
        'Após anos de pesquisa, Indiana Jones descobre um antigo mapa que o leva a uma jornada épica em busca de um tesouro lendário perdido nas profundezas da selva amazônica.',
        '6,5/10',
        false),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Lista de filmes'),
      ),
      body: ListView.builder(
        itemCount: film.length,
        itemBuilder: (BuildContext context, int index) {
          return Padding(
            padding: const EdgeInsets.only(
              left: 10.0,
              right: 22.0,
              top: 10.0,
              bottom: 10.0,
            ),
            child: Row(
              children: [
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => DetailScreen(films: film[index]),
                      ),
                    );
                  },
                  child: Image.asset(
                    film[index].image,
                    width: 110,
                    height: 170,
                  ),
                ),
                SizedBox(
                  width: 20,
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        film[index].title,
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        film[index].date,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                          height: 2,
                        ),
                      ),
                      Text(
                        film[index].tags,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                          color: Colors.white54,
                        ),
                      ),
                      SizedBox(
                        height: 4,
                      ),
                      GestureDetector(
                        onTap: () {
                          setState(
                            () {
                              if (film[index].favorite == false) {
                                film[index].favorite = true;
                              } else {
                                film[index].favorite = false;
                              }
                            },
                          );
                        },
                        child: Icon(
                          film[index].favorite
                              ? Icons.bookmark
                              : Icons.bookmark_border,
                          size: 32,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
