class Films {
  String image;
  String tags;
  String title;
  String director;
  String date;
  String descricao;
  String rate;
  bool favorite;
  Films(this.image, this.tags, this.title, this.director, this.date,
      this.descricao, this.rate, this.favorite);
}