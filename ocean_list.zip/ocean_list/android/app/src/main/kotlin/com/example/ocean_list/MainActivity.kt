package com.example.ocean_list

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
