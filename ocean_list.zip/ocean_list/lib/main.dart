import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  final List<Contato> contatos = [
    Contato('Felipe', 'felipe@gmail.com', 'images/filme7.png', false),
    Contato('Carlos', 'carlos@gmail.com', 'images/filme6.png', false),
    Contato('Carlos', 'carlos@gmail.com', 'images/filme5.png', false),
    Contato('Pedro', 'pedro@gmail.com', 'images/filme4.png', false),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: ListView.builder(
        itemCount: contatos.length,
        itemBuilder: (BuildContext context, int index) {
          /* String firstLetter = contatos[index].nome[0].toUpperCase(); */
          return ListTile(
            leading: Image.asset(
              (contatos[index].image),
            ),
            title: Text(contatos[index].nome),
            subtitle: Text(contatos[index].email),
            trailing: IconButton(
              icon: contatos[index].favorite ? Icon(Icons.favorite) : Icon(Icons.favorite_border),
              onPressed: () {
                setState(
                            () {
                              if (contatos[index].favorite == false) {
                                contatos[index].favorite = true;
                              } else {
                                contatos[index].favorite = false;
                              }
                            },
                          );
              },
            ),
          );
        },
      ),
    );
  }
}

class Contato {
  String nome;
  String email;
  String image;
  bool favorite;
  Contato(this.nome, this.email, this.image, this.favorite);
}
